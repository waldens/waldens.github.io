// ==UserScript==
// @name         Direct download from Google Play
// @namespace    StephenP
// @version      1.6.4
// @description  Adds APKPure, APKMirror, APK-DL and Evozi download buttons to Google Play when browsing apps. This script is based on yurenchen's "google play apk downloader".
// @author       StephenP
// @match        https://play.google.com/*
// @match        http://play.google.com/*
// @grant        none
// ==/UserScript==
var evoziURL;
var apkdlURL;
var apkmirrorURL;
var apkpureURL;
var id;
var menubutton;
var wlButton;
var buttonslist;
var html;
var pageURL;
(function() {
    'use strict';
    pageURL=location.href;
    if(pageURL.includes("details?id=")){
       addButtons();
    }
    setInterval(checkReload, 3000);
})();
function checkReload(){
    if(pageURL!=location.href){
        //alert(document.getElementById("apkdlbutton"));
        while(document.getElementById("apkdlbutton")!==null){//se ci sono ancora i pulsanti
            setTimeout(function(){},1000);
        }
        while(document.getElementsByClassName("buy-button-container")===null){
            setTimeout(function(){},1000);
        }
        //alert(pageURL+" vs. "+location.href);
        if(location.href.includes("details?id=")){
            addButtons();
        }
        pageURL=location.href;
        wlButton=null;
    }
}
function addButtons(){
        if(document.getElementsByClassName("buy")[0].firstElementChild.firstElementChild.getElementsByTagName("META")[1].content==0){
            id=location.search.match(/id=(.*)/)[1].split("&", 1);
            apkpureURL='https://apkpure.com/genericApp/'+id+'/download';
            evoziURL='https://apps.evozi.com/apk-downloader/?id='+id;
            apkdlURL='http://apkfind.com/store/captcha?app='+id;
            apkmirrorURL='https://www.apkmirror.com/?post_type=app_release&searchtype=apk&s='+id;
            menubutton=document.getElementsByClassName("action-bar-menu-button").length;
            wlButton = document.createDocumentFragment();
            wlButton.appendChild(document.getElementsByClassName("id-wishlist-display")[0]);
            if(menubutton!==0){ //menubutton==0 means there is no sliding menu, an element only occurring in mobile view.
                buttonslist = document.getElementsByClassName("details-actions")[0];
                html='<span id="apkpurebutton"><a href="'+apkpureURL+'" style="background-color: #24cd77" class="medium play-button download-apk-button apps ">APKPure</a></span><span id="apkdlbutton"><a href="'+apkdlURL+'" style="background-color: #009688" class="medium play-button download-apk-button apps ">APK-DL</a></span><span><a href="'+evoziURL+'" style="background-color: #286090" class="medium play-button download-apk-button apps ">Evozi</a></span><span><a href="'+apkmirrorURL+'" style="background-color: #FF8B14" class="medium play-button download-apk-button apps ">APKMirror</a></span>';
            }
            else{
                buttonslist = document.getElementsByClassName("details-actions-right")[0]; 
                html='<span id="apkpurebutton"><a href="'+apkpureURL+'" style="background-color: #24cd77" class="large play-button download-apk-button apps ">APKPure</a></span><span id="apkdlbutton"><a href="'+apkdlURL+'" style="background-color: #009688" class="large play-button download-apk-button apps ">APK-DL</a></span><span><a href="'+evoziURL+'" style="background-color: #286090" class="large play-button download-apk-button apps ">Evozi</a></span><span><a href="'+apkmirrorURL+'" style="background-color: #FF8B14" class="large play-button download-apk-button apps ">APKMirror</a></span>';
            }    
            buttonslist.innerHTML=buttonslist.innerHTML+html;
            buttonslist.appendChild(wlButton);
        }
}