// ==UserScript==
// @name        • Disucz论坛 自动签到
// @namespace   bootislands
// @description disucz论坛 轻量版的自动签到
// @include     *tushuku.net/plugin.php?id=dsu_paulsign:sign*
// @include     *eshuyuan.net/plugin.php?id=dsu_paulsign:sign*
// @include     /^https?://[^\/]+/plugin.php?id=mpage_sign:sign.*/
// @version     20150305
// @grant       none
// ==/UserScript==

document.getElementById('todaysay').setAttribute('value', '。。');
document.getElementById('yl').click();

