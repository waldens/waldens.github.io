// ==UserScript==
// @name         • 移除 reddit 的 nsfw 内容
// @namespace    http://tampermonkey.net/
// @version      1
// @description  主要用于移除 r/all中的nsfw内容
// @grant        none
// @include      http*://www.reddit.com/r/all/
// ==/UserScript==

(function() {
    'use strict';

    blockAll();

    var mo = new MutationObserver(function(allmutations) {
        blockAll();
    });
    mo.observe(document.querySelector('body'), {'childList': true,'characterData':false,'subtree': true});

    function blockAll() {
            $('.nsfw-stamp').parent().parent().parent().parent().parent().remove();
    }
})();