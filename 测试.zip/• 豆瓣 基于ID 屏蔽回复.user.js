// ==UserScript==
// @name           • 豆瓣 基于ID 屏蔽回复
// @namespace      lisanye
// @description    豆瓣 基于ID 屏蔽回复
// @include        https://www.douban.com/group/topic/*
// @version        20170428
// @grant          none
// @run-at         document-end
// ==/UserScript==

blockAll();

var mo = new MutationObserver(function(allmutations) {
    blockAll();
});
mo.observe(document.querySelector('body'), {'childList': true,'characterData':false,'subtree': true});

function blockAll() {
		var dogs = new Array("shh2", "157179029", "liyang");
		var dogtitles = new Array("签到", "水果乐园");

		// 内容页 针对ID
		for (x in dogs) {
			dog = document.evaluate("//*[contains(@class, 'comment-item')][div/div/h4/a[contains(@href,'" + dogs[x] + "')]]", document, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
			if (dog.snapshotLength) {
				for (var i = 0, c = ""; i < dog.snapshotLength; i++) {
					dog.snapshotItem(i).innerHTML = "";
				}
			}
		}

		// 不明
		for (x in dogs) {
			dog = document.evaluate('//table/tbody[tr[1]/td[1]/div[1]//font[text()="' + dogs[x] + '"]]', document, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
			if (dog.snapshotLength) {
				for (var i = 0, c = ""; i < dog.snapshotLength; i++) {
					c = String(dog.snapshotItem(i).firstChild.childNodes[3].textContent.match(/\d+#/)).replace(/#/, "楼");
					dog.snapshotItem(i).innerHTML = "<b><center>c被屏蔽帖子 " + c + " <font color=red>" + dogs[x] + "</font></center></b>";
					//dog.snapshotItem(i).innerHTML = "";
				}
			}
		}
}