// ==UserScript==
// @name					• Diigo Expand More Annotation.
// @namespace			bootislands
// @description		自动展开diigo My Library中的More Annotation...
// @version				20140702.1
// @include				https://www.diigo.com/user/*
// @author				bootislands#163dotcom
// @grant               none
// ==/UserScript==

window.setTimeout( function() {
    var posts = document.querySelectorAll(".showMoreBtn");
    for (floor = 0; floor < posts.length; floor++) {
        var post = posts[floor];
        post.click();
    }
},5200);
