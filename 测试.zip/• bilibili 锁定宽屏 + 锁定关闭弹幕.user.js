// ==UserScript==
// @name         • bilibili 锁定宽屏 + 锁定关闭弹幕
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  bilibili 保持宽屏
// @author       You
// @match        http*://www.bilibili.com/video/av*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    setInterval(function() {
        var div = document.querySelector(".bilibili-player-iconfont-widescreen");
        if ( div.getAttribute("data-text") == "宽屏模式" ) {
            div.click();
        }
        var div1 = document.querySelector(".bilibili-player-iconfont-danmaku");
        if ( document.defaultView.getComputedStyle(div1,null).display == "block" ) {
            div1.click();
        }
    }, 100);
})();