// ==UserScript==
// @name        • 已点击图片 高亮
// @namespace   bootislands
// @include     *
// @include     http://*.xueui.cn/*
// @include     https://www.gay-torrents.net/*
// @exclude     http://walden.farbox.com/*
// @version     1
// @description 给看过的网页点提示，以免重复看
// @grant       GM_addStyle
// ==/UserScript==

GM_addStyle("a > img { border: 1px solid white }");
GM_addStyle("a:visited > img { border-color: red !important }");
GM_addStyle("a:visited { color: #e71d36 !important; }")

document.body.addEventListener("click", function(event) {
  var t = event.target;
  if (t.tagName === "IMG" && t.parentNode.tagName === "A") {
    var url = t.parentNode.href;
    var f = document.createElement("iframe");
    f.style.display = "none";
    f.src = url;
    document.body.appendChild(f);
  }
}, false);