// ==UserScript==
// @name            Book - 读秀显示SS
// @namespace       bootislands
// @description     读秀搜索结果（普通、高级、专业）页面中显示SS
// @include         http://book.duxiu.com/search*
// @include         http://book.duxiu.com/advsearch*
// @include         http://book.duxiu.com/expsearch*
// @include         http://books.gdlink.net.cn/search*
// @include         http://book.szdnet.org.cn/search*
// @include         http://book.szdnet.org.cn/advsearch*
// @include         http://book.szdnet.org.cn/expsearch*
// ==/UserScript==

function addSingleSSno (NthItem) {
	var valueOfIdAttrb = 'ssid' + NthItem;
	var ssValue = document.getElementById(valueOfIdAttrb).value;

    //插入文件名
    var title = 'title' + NthItem
    var titleValue = document.getElementById(title).value.replace(/<.*?>/g, '');
    var descrp = 'memo' + NthItem
    var lastPartValue = document.getElementById(descrp).value.replace(/<.*?>/g, '').replace(/作者:(\S*?)(\s页数:(\S*?))?\s出版社:(.*?)\s出版日期:(\S*?)\s.*/, '@$1@$4@$5')
    var wholeBookName = titleValue + '@' + ssValue + lastPartValue

    //操作DOM
    var targetSSEle = document.createElement('div');
	targetSSEle.innerHTML='<span style="display: inline-block; right-margin: 10px;"><input size="8" style="font-weight:bold;font-size:20px;color:darkgreen;" value='+ssValue+' onMouseOver="this.select()"></input></span>'
                + '<span><input size="8" style="font: 12px/1.5 "宋体"; color:rgb(102, 102, 102);" value='
                + wholeBookName.replace(/ /g, '&nbsp;') + ' onMouseOver="this.select()"></input></span>';
	var actualNth = NthItem + 1;
	var xpathExp = './/table[@class="book1"][' + actualNth + ']//td[2]';
	var parent = document.evaluate(xpathExp, document, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
	var insertTarget = parent.snapshotItem(0);
	insertTarget.insertBefore(targetSSEle,parent.firstChild);


}

function addLocalFileName (NthItem) {


}

for(n=0, stopTag = 0; n<=9; n++){
	addSingleSSno(n);
	}
//console.log(ssid)