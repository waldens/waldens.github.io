// ==UserScript==
// @name       QQ快捷登录去除多余权限
// @namespace       QQ quick login
// @version       1.0.0
// @description       这是一个用于去除QQ快捷登的多余权限勾选的脚本
// @include       /^https?:\/\/graph\.qq\.com\/oauth\/show\?which=.*$/
// @run-at       document-end
// ==/UserScript==
document.getElementById('select_all').click();