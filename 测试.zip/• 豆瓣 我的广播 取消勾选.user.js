// ==UserScript==
// @name        • 豆瓣 我的广播 取消勾选
// @namespace   bootislands
// @description 取消勾选 发到我的广播
// @include     https://www.douban.com/game/*
// @version     1
// @grant       none
// ==/UserScript==

// 取消选择
 $("*").mousedown(function(){
  $("input[name='share-shuo']").each(function(){
   $(this).attr("checked",false);
  });
 });

// $("input[name='share-shuo']").attr("checked",false);