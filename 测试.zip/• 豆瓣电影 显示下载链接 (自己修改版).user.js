// ==UserScript==
// @id           heawercher@gmail.com
// @name         • 豆瓣电影 显示下载链接 (自己修改版)
// @namespace    Chang_way_enjoying
// @version      0.7.2_2016-07-20
// @description  在 movie.douban.com 网站下直接显示下载链接，可通过多个站点获取。
// @author       c wt U r
// @match        https://movie.douban.com/subject/*
// @connect      mp4ba.com
// @connect      4567.tv
// @require      https://cdn.bootcss.com/jquery/2.2.3/jquery.min.js
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// ==/UserScript==



function getDoc(url, callback) {
    GM_xmlhttpRequest({
        method: 'GET',
        url: url,
        headers: {
            'User-agent': window.navigator.userAgent,
            'Content-type': null
        },
        onload: function (responseDetail) {
            var doc = '';
            if (responseDetail.status == 200) {
                // For Firefox, Chrome 30+ Supported
                doc = new DOMParser().parseFromString(responseDetail.responseText, 'text/html');
                if (doc === undefined) {
                    doc = document.implementation.createHTMLDocument("");
                    doc.querySelector('html').innerHTML = responseText;
                }
            }
            callback(doc, responseDetail.finalUrl);
        }
    });
}
function postDoc(url, callback, data) {
    GM_xmlhttpRequest({
        anonymous: true,
        method: 'POST',
        url: url,
        headers: {
            'User-agent': window.navigator.userAgent,
            'Content-type': 'application/x-www-form-urlencoded'
        },
        data: data,
        onload: function (responseDetail) {
            callback(responseDetail.responseText, responseDetail.finalUrl);
        }
    });
}

function ad() {
    var strCSS = "";
    strCSS += "#dale_movie_subject_top_right,";
    strCSS += "#dale_movie_subject_top_midle,";
    strCSS += "#content div.qrcode-app,";
    strCSS += "#content div.ticket";
    strCSS += "{display:none}";

    document.head.appendChild(document.createElement("style")).textContent = strCSS;
}
ad();

var movieTitle = $("#content > h1 > span")[0].textContent.split(" ")[0];

function imdb() {
    imdb = $("div#info a[href^='http://www.imdb.com/title/tt']");
    imdbS = imdb.text();
    if (imdbS && imdbS.startsWith('tt')) {
        imdbS = imdbS.slice(2);

        kickass();
    }
}
function kickass() {
    var noAdcancedSearch = true;
    var kickass = "https://kat.al/";

    if  (noAdcancedSearch){
        kickass = $("<a href=\"" + kickass +"\" target=\"_blank\" rel=\"nofollow\" style=\"margin-left: 6px;\">kickass</a>");
        imdb.after(kickass);
    }else{
        kickass = $("<a href=\"" + kickass + "usearch/imdb:" + imdbS + "/\" target=\"_blank\" rel=\"nofollow\" style=\"margin-left: 6px;\">kickass</a>");
        imdb.after(kickass);
    }

}
imdb();
////////////////////////////////////////
function part_sites() {
    var str = "";
    str += ".sites {";
    str += "    margin-bottom:30px;";
    str += "    background: #F4F4EC;";
    str += "}";
    str += ".sites-body {";
    str += "    line-height:24px;";
    str += "    letter-spacing:-0.31em;";
    str += "    *letter-spacing:normal;";
    str += "}";
    str += ".sites-body a {";
    str += "    display:inline-block;";
    str += "    *display:inline;";
    str += "    letter-spacing:normal;";
    str += "    margin:0 8px 8px 0;";
    str += "    padding:0 8px;";
    str += "    background-color:#f5f5f5;";
    str += "    -webkit-border-radius:2px;";
    str += "       -moz-border-radius:2px;";
    str += "            border-radius:2px;";
    str += "}";
    str += "";
    str += ".sites-body a:link,";
    str += ".sites-body a:visited {";
    str += "    background-color:#f5f5f5;";
    str += "    color: #37A;";
    str += "}";
    str += "";
    str += ".sites-body a:hover,";
    str += ".sites-body a:active {";
    str += "    background-color: #e8e8e8;";
    str += "    color: #37A;";
    str += "}";
    str += ".sites, .netdiskLinks {";
    str += "    padding: 10px;";
    str += "}";
    // str += ".sites-body a.sites_r0 {";
    // str += "    text-decoration: line-through;";
    // str += "}";

    document.head.appendChild(document.createElement("style")).textContent = str;


    // add the sites part
    str = "";
    str += "<div class=\"sites\">     ";
    str += "    <h2>";
    str += "        <i class=\"\">电视剧</i>";
    str += "              · · · · · ·";
    str += "    </h2>";
    str += "        <div class=\"sites-body\">";
    str += "        </div>";
    str += "    </div>";

    var sites = $(str);
    $("#content div.tags").before(sites);
}
part_sites();
var sites = [];
function add_sitelink(link, title, text) {
    if (!text){
        text = title;
    }
    if (title) {
        // title += " (*)";
    } else {
        return;
    }

    link = $("<a href=\"" + link + "\" class=\"\" target=\"_blank\" rel=\"nofollow\" title=\"" + title + "\">" + text + "</a>");
    link = $("#content div.sites-body").append(link);
    link = link.children();
    link = link[link.length -1];
    sites.push(link);

}
//add_sitelink("http://cili03.com/?topic_title3=" + movieTitle, "cili03.com", "CILI001");
//add_sitelink("http://www.bttiantang.com/s.php?q=" + movieTitle, "bttiantang.com", "BT天堂");
//add_sitelink("http://www.zimuku.net/search?q=" + movieTitle, "zimuku.net", "字幕库");
//add_sitelink("http://www.zimuzu.tv/search/index?keyword=" + movieTitle, "zimuzu.tv", "字幕组");

//add_sitelink("http://www.xunyingwang.com/search?q=" + movieTitle, "xunyingwang.com", "迅影网");


add_sitelink("http://www.dysfz.cc/key/" + movieTitle + "/", "dysfz.cc", "电影首发站");
add_sitelink("http://www.zmz2017.com/search/index?keyword=" + movieTitle, "zmz2017.com", "人人影视");
add_sitelink("http://www.ttmeiju.com/index.php/search/index.html?keyword=" + movieTitle, "ttmeiju.com", "天天美剧");
add_sitelink("http://search.bilibili.com/all?keyword=" + movieTitle, "bilibili.com", "bilibili");
add_sitelink("http://www.lbldy.com/search/" + movieTitle, "lbldy.com", "龙部落");
add_sitelink("http://www.hanfan.cc/?s=" + movieTitle, "hanfan.com", "韩饭网");

////////////////////////////////////////
function part_netdisk() {
    var str = "";
    str += ".netdiskLinks {";
    str += "    margin-bottom:30px;";
    str += "    background: #F4F4EC;";
    str += "}";
    str += ".netdiskLinks-body {";
    str += "    line-height:24px;";
    str += "    letter-spacing:-0.31em;";
    str += "    *letter-spacing:normal;";
    str += "}";
    str += ".netdiskLinks-body a {";
    str += "    display:inline-block;";
    str += "    *display:inline;";
    str += "    letter-spacing:normal;";
    str += "    margin:0 8px 8px 0;";
    str += "    padding:0 8px;";
    str += "    background-color:#f5f5f5;";
    str += "    -webkit-border-radius:2px;";
    str += "       -moz-border-radius:2px;";
    str += "            border-radius:2px;";
    str += "}";
    str += "";
    str += ".netdiskLinks-body a:link,";
    str += ".netdiskLinks-body a:visited {";
    str += "    background-color:#f5f5f5;";
    str += "    color: #37A;";
    str += "}";
    str += "";
    str += ".netdiskLinks-body a:hover,";
    str += ".netdiskLinks-body a:active {";
    str += "    background-color: #e8e8e8;";
    str += "    color: #37A;";
    str += "}";

    document.head.appendChild(document.createElement("style")).textContent = str;


    // add the netdiskLinks part
    str = "";
    str += "<div class=\"netdiskLinks\">     ";
    str += "    <h2>";
    str += "        <i class=\"\">电影</i>";
    str += "              · · · · · ·";
    str += "    </h2>";
    str += "        <div class=\"netdiskLinks-body\">";
    str += "        </div>";
    str += "    </div>";

    var netdiskLinks = $(str);
    $("#content div.tags").before(netdiskLinks);

}
part_netdisk();
function add_netdisklink(link, title, text) {
    if (!title) {
        title = "百度网盘";
    }
    if (!text) {
        text = "加密分享";
    }
    link = $("<a href=\" " + link + " \" class=\"\" target=\"_blank\" rel=\"nofollow\" title=\"" + title + "\">"+ text +"</a>");
    $("#content div.netdiskLinks-body").append(link);
}
// add_netdisklink("http://www.wangpansou.cn/s.php?op=baipan&q=" + movieTitle, "wangpansou.cn", "网盘搜搜");
add_netdisklink("https://moviejie.com/search/q_" + movieTitle + "/", "moviejie.com", "电影街");
add_netdisklink("http://www.mp4ba.com/search.php?keyword=" + movieTitle, "MP4ba.com", "MP4吧");
add_netdisklink("http://www.dysfz.cc/key/" + movieTitle + "/", "dysfz.cc", "电影首发站");
add_netdisklink("http://www.btbtt.la/search-index-keyword-" + movieTitle + ".htm", "btbtt.la", "BT之家");


// function site_4567() {
//     if (!movieTitle) {
//         return;
//     }
//     var url = "http://www.4567.tv/search.asp";
//     var data = "typeid=2&keyword=" + encodeURI(movieTitle);
//
//     postDoc(url, function (doc) {
//         console.log(doc.length);
//         var urls = $("div.movielist a",  doc);
//         console.log(urls.length);
//         for (i = 0; i < urls.length; i++) {
//             var url = "http://www.4567.tv/" + urls[i].getAttribute("href");
//             console.log(url);
//             getDoc(url, function (doc, url) {
//                 parse_netdisklink(doc.body.outerText);
//             });
//         }
//     },data);
// }
// site_4567();

// TODO 4567.tv
// TODO baiduyunwangpan.com
// TODO http://www.kanguome.com/

function part_customizeSearch() {
    var str = "";
    str += ".customizeSearch {";
    str += "    margin-bottom:30px;";
    str += "    background: #F4F4EC;";
    str += "}";
    str += ".customizeSearch-body {";
    str += "    line-height:24px;";
    str += "    letter-spacing:-0.31em;";
    str += "    *letter-spacing:normal;";
    str += "}";
    str += ".customizeSearch-body a {";
    str += "    display:inline-block;";
    str += "    *display:inline;";
    str += "    letter-spacing:normal;";
    str += "    margin:0 8px 8px 0;";
    str += "    padding:0 8px;";
    str += "    background-color:#f5f5f5;";
    str += "    -webkit-border-radius:2px;";
    str += "       -moz-border-radius:2px;";
    str += "            border-radius:2px;";
    str += "}";
    str += "";
    str += ".customizeSearch-body a:link,";
    str += ".customizeSearch-body a:visited {";
    str += "    background-color:#f5f5f5;";
    str += "    color: #37A;";
    str += "}";
    str += "";
    str += ".customizeSearch-body a:hover,";
    str += ".customizeSearch-body a:active {";
    str += "    background-color: #e8e8e8;";
    str += "    color: #37A;";
    str += "}";

    document.head.appendChild(document.createElement("style")).textContent = str;


    // add the netdiskLinks part
//     str = "";
//     str += "<div class=\"customizeSearch\">     ";
//     str += "    <h2>";
//     str += "        <i class=\"\">自定义搜索</i>";
//     str += "              · · · · · ·";
//     str += "    </h2>";
//     str += "        <div class=\"customizeSearch-body\">";
//     str += "        </div>";
//     str += "    </div>";

    var customizeSearch = $(str);
    $("#content div.tags").before(customizeSearch);

}
part_customizeSearch();
function add_customizeSearch(link, title, text) {
    if (!title) {
        title = "自定义搜索";
    }
    if (!text) {
        text = "自定义搜索";
    }
    link = $("<a href=\" " + link + " \" class=\"\" target=\"_blank\" rel=\"nofollow\" title=\"" + title + "\">"+ text +"</a>");
    $("#content div.customizeSearch-body").append(link);
}
// add_customizeSearch("https://www.google.com/search?q=site:pan.baidu.com " + movieTitle, "谷歌搜百度网盘 site:pan.baidu.com", "goBaiduDisk");
// add_customizeSearch("http://www.bing.com/search?q=site:pan.baidu.com " + movieTitle, "必应搜百度网盘 site:pan.baidu.com", "biBaiduDisk");
// add_customizeSearch("https://www.baidu.com/s?wd=" + movieTitle + " rip BD", "百度 rip BD", "baiKeyS");
// add_customizeSearch("https://www.google.com/search?q=" + movieTitle + " rip BD", "谷歌 rip BD", "gooKeyS");
// add_customizeSearch("https://www.baidu.com/s?wd=inurl:" + movieTitle + " http://pan.baidu.com/s/", "百度搜百度网盘 http://pan.baidu.com/s/", "baiPanKeyS");
// add_customizeSearch("https://www.google.com/search?q=inurl:" + movieTitle + " http://pan.baidu.com/s/", "谷歌搜百度网盘 http://pan.baidu.com/s/", "goPanKeyS");
// add_customizeSearch("http://www.bing.com/search?q=inurl:" + movieTitle + " http://pan.baidu.com/s/", "必应搜百度网盘 http://pan.baidu.com/s/", "biPanKeyS");
