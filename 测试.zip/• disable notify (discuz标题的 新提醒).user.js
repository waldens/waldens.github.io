
// ==UserScript==
// @name        • disable notify (discuz标题的 新提醒)
// @namespace   shinybbs
// @description disable notify
// @include        */viewthread.php*
// @include        */thread*
// @include        */redirect.php*
// @include        */forum-redirect-tid*
// @include        */forum-viewthread-tid*
// @include        */forum.php?mod=viewthread*
// @include        */forum.php?mod=forumdisplay*
// @include        */forum-*.html
// @include     http://www.shinybbs.com/*
// @include     http://www.dszw.net/
// @version     1
// @grant       none
// ==/UserScript==
window.onload = setTimeout(init,1000);
function init() {
   _element = document.getElementById("myprompt_menu");

  if(_element.innerHTML.indexOf("新听众")> -1){
       _parentElement = _element.parentNode;
      if(_parentElement){
       _parentElement.removeChild(_element);
      }

      var _element = document.getElementById("myprompt");
      var _parentElement = _element.parentNode;
      if(_parentElement){
       _parentElement.removeChild(_element);
      }
      //myprompt_menu




      //http://www.shinybbs.com/home.php?mod=follow&do=follower
     //var sb = window.open("http://www.shinybbs.com/home.php?mod=follow&do=follower",'mywin','left=20,top=20,width=1,height=1,toolbar=1,resizable=0');
     //setTimeout("sb.close()",1000);
  }
      var title = document.getElementsByTagName("title")[0];
      var text = title.innerHTML;

      if(text.indexOf("【新提醒】") > -1){
        var len = "【新提醒】".length;
        title.innerHTML = text.substring("【新提醒】".length);
      }

}
