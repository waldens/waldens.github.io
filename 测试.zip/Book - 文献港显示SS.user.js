// ==UserScript==
// @name            Book - 文献港显示SS
// @namespace       wenxiangang
// @description     文献港收录页面显示SS
// @include         http://book.szdnet.org.cn/views/specific/*
// ==/UserScript==

(function() {
    var ssid = document.querySelector("#libinfo ~ script").innerHTML.replace(/[\s\S]*?&ssn=(\d\d\d\d\d\d\d\d)&[\s\S]*/i, "$1");

    var titleValue = document.getElementsByClassName('tutilte')[0].textContent
    console.log(titleValue);
    console.log(ssid);
    var lastPartValue = allinfo.replace(/\|\|[\d\-X]+$/, '').replace(/\|\|/g, '@')  //去掉末尾ISBN，且替换为下划线_连接符
    console.log(lastPartValue);
    var wholeBookName = titleValue + '@' + ssid + '@' + lastPartValue


    var ta = document.createElement('div');
    ta.innerHTML = '<input size="8" style="font-weight:bold;font-size:20px;color:darkgreen;" value=' + ssid + ' onMouseOver="this.select()"></input>';
    var taWholeName = document.createElement('div');
    taWholeName.innerHTML = '<input size="8" style="font: 12px/1.5 "宋体"; color:rgb(102, 102, 102);" value='
                + wholeBookName.replace(/ /g, '&nbsp;') + ' onMouseOver="this.select()"></input></span>';

    var parent = document.getElementsByClassName('tubookimg')[0];
    parent.insertBefore(taWholeName, parent.firstChild);
    parent.insertBefore(ta, parent.firstChild);
})();
