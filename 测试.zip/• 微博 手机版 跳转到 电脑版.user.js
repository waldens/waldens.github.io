// ==UserScript==
// @name        • 微博 手机版 跳转到 电脑版
// @namespace   lilisan
// @include     http://m.weibo.cn/*
// @version     1
// @require     http://cdn.bootcss.com/jquery/3.1.1/jquery.min.js
// @grant       none
// ==/UserScript==

$.get(window.location.href,function(res){
   var url_part2 = res.replace(/.*?"bid":"([^"]{7,11})","pics".*/g, "$1");
   var url = window.location.href;
   var url_part1 = url.replace(/https?:\/\/[^\/]+\/([^\/]+)\/.*/, "$1")
   window.location.href = "http://www.weibo.com/" + url_part1 + "/" + url_part2;
});