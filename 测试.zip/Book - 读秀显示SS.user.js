// ==UserScript==
// @name            Book - 读秀显示SS
// @namespace       duxiu
// @description     读秀收录页面显示SS
// @include         http://*.duxiu.com/*
// ==/UserScript==

(function () {
var ssid = document.getElementsByName('ssid')[0].value;
var ta = document.createElement('div');
ta.innerHTML='<input size="8" style="font-weight:bold;font-size:20px;color:darkgreen;" value='+ssid+' onMouseOver="this.select()"></input>';
var parent = document.getElementsByClassName('left photo')[0];
parent.insertBefore(ta,parent.firstChild);
})();
