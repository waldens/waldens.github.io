// ==UserScript==
// @name                Show Pic
// @name:zh-CN         • 外链图片自动载入 (重命名名称版)
// @description       直接显示图片
// @include             *
// ==/UserScript==
// 修改自“豆瓣助手 douban helper”脚本
// 豆瓣助手 脚本地址  http://userscripts.org/scripts/show/49911

show_pic();
/* ************************ 图片识别处理 ************************ */

// 检测、显示图片函数
function show_pic(){
	var a_links = document.links;
	_pic_ = /^http\S*\.(?:jpg|jpeg|jpe|jfif|bmp|png|gif|tif|tiff|ico)/i;
	switch ( parseInt(GM_getValue("choice", 1)) ){
	case 0:
		break;
	case 1:// 直接显示图片
		for (var i=0,n=a_links.length; i<n; i++){
			checkIMG(a_links[i]);
		};
		break;
// 	case 2:// 点击时才检测图片
// 		for (var i=0,n=a_links.length; i<n; i++){
// 			a_links[i].addEventListener("mousedown", function(e){
// 				(e.button == 1) && checkIMG(this)
// 			}, false);
// 		};
// 		break;
	}
};

//检测图片
function checkIMG(link){
	var href = link.href;
	var inner = link.innerHTML;
	if ( _pic_.test(href) && !/<img\s/i.test(inner) ){
		link.addEventListener("mousedown", function(e){
			(e.button == 1) && toggle(this.childNodes[0]) && toggle(this.childNodes[1])// 图片\链接切换
		}, false);
		link.innerHTML = '<img style="max-width:520px;" alt="图片载入ing..." title="点击鼠标中键可切换链接/图片 by豆瓣助手" src="' + href + '" /><span style="display:none;">' + inner + '</span>';
	}
};