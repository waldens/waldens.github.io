// ==UserScript==
// @name        • 水木简洁样式
// @namespace   lilisan
// @include     http://www.newsmth.net/nForum/*
// @require     http://cdn.bootcss.com/jquery/1.7.2/jquery.min.js
// @require     https://gist.github.com/raw/2625891/waitForKeyElements.js
// @version     1
// @grant       GM_addStyle
// ==/UserScript==

waitForKeyElements (".a-body .a-content > p", actionFunction);

function actionFunction (jNode) {
    var nodes = document.querySelectorAll(".a-body .a-content > p");
    var nodesLength = nodes.length;
    for (var temp = 0; temp < nodesLength; temp++) {
      var node = nodes[temp];
      var test = node.innerHTML.replace(/.*?站内 <br>&nbsp;&nbsp;<br>/ig, '');
      test = test.replace(/<font class="f006">※ .*?<\/font>/ig, '');
//       test = test.replace('<br> -- <br>&nbsp;&nbsp;<br>', '');
      test = test.replace(/<br> -- <br>.*/ig, '').replace(/<br>&nbsp;&nbsp;/ig, '')
      test = test.replace('&nbsp;&nbsp;<br>', '');
      node.innerHTML = test;
    }
}

