// ==UserScript==
// @name        • anti-anti-copy (for 知乎)
// @namespace   anti-anti-copy
// @include     http*://www.zhihu.com/*
// @version     1
// @grant       none
// @run-at      document-end
// ==/UserScript==

document.addEventListener("copy", function(e){e.stopPropagation()}, true);