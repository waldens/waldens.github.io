// ==UserScript==
// @name         • 隐藏mobileread的置顶帖sticky
// @namespace    hehe
// @version      0.1
// @description  Hides stickied threads in forum groups
// @author       hehe
// @require      https://cdn.bootcss.com/jquery/2.2.3/jquery.min.js
// @include      *mobileread.com*
// @grant        none
// ==/UserScript==
/*jshint multistr: true */

this.$ = this.jQuery = jQuery.noConflict(true);

(function() {
    'use strict';

    $('#threadbits_forum_166 > tr > td > div > span.sticky').parent().parent().parent().hide();
})();