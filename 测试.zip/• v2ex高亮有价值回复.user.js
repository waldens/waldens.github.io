// ==UserScript==
// @name        • v2ex高亮有价值回复
// @namespace   xiaopenyou@v2ex
// @include     http*://*v2ex.com/t/*
// @version     2
// @description v2ex回帖中，被感谢过的楼层(通常更有价值)，进行高亮
// @grant       none
// ==/UserScript==

window.setTimeout( function() {
   var nodes = document.querySelectorAll(".cell .fade.small, .inner .fade.small");
   var nodesLength = nodes.length
   for (var temp = 0; temp < nodesLength; temp++) {
     var node = nodes[temp];
     if(node.innerHTML.indexOf("♥") != -1) {
        var todoNode = node.parentNode.parentNode.parentNode.parentNode.parentNode;
        todoNode.style.setProperty('background-color','rgba(161, 181, 216, 0.2)');
     }
     else {
        var todoNode = node.parentNode.parentNode.parentNode.parentNode.parentNode;
        todoNode.style.setProperty('background-color','rgb(255, 255, 255)');
     }
   }
},5200);
